"use strict";(self.webpackChunk_by_l_react_form=self.webpackChunk_by_l_react_form||[]).push([[904],{20880:function(i,n,e){e.r(n),e.d(n,{demos:function(){return s}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(28543),g=e(84347),u=e(4966),c=e(84434),s={"docs-entities-pc-01-start-demo-01-start":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,79848))})),asset:{type:"BLOCK",id:"docs-entities-pc-01-start-demo-01-start",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(67795).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z}},entry:"index.tsx"},context:{"@by-l/react-form":g,antd:u,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":c},renderOpts:{compile:function(){var o=v()(r()().mark(function m(){var p,M=arguments;return r()().wrap(function(I){for(;;)switch(I.prev=I.next){case 0:return I.next=2,e.e(417).then(e.bind(e,78235));case 2:return I.abrupt("return",(p=I.sent).default.apply(p,M));case 3:case"end":return I.stop()}},m)}));function a(){return o.apply(this,arguments)}return a}()}}}},69961:function(i,n,e){e.r(n),e.d(n,{demos:function(){return a}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(945),g=e(84347),u=e(4966),c=e(84434),s=e(82159),o=e(74106),a={"docs-entities-pc-02-login-d-demo-02-login-d":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,27545))})),asset:{type:"BLOCK",id:"docs-entities-pc-02-login-d-demo-02-login-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(49956).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":g,antd:u,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":c,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":s,"/Users/boyang/code/react/react-form/src/examples/index.css":o},renderOpts:{compile:function(){var m=v()(r()().mark(function M(){var y,I=arguments;return r()().wrap(function(E){for(;;)switch(E.prev=E.next){case 0:return E.next=2,e.e(417).then(e.bind(e,78235));case 2:return E.abrupt("return",(y=E.sent).default.apply(y,I));case 3:case"end":return E.stop()}},M)}));function p(){return m.apply(this,arguments)}return p}()}}}},112:function(i,n,e){e.r(n),e.d(n,{demos:function(){return a}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(61091),g=e(84347),u=e(4966),c=e(82159),s=e(84434),o=e(74106),a={"docs-entities-pc-02-login-demo-02-login":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,9333))})),asset:{type:"BLOCK",id:"docs-entities-pc-02-login-demo-02-login",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(59254).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":g,antd:u,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/index.css":o},renderOpts:{compile:function(){var m=v()(r()().mark(function M(){var y,I=arguments;return r()().wrap(function(E){for(;;)switch(E.prev=E.next){case 0:return E.next=2,e.e(417).then(e.bind(e,78235));case 2:return E.abrupt("return",(y=E.sent).default.apply(y,I));case 3:case"end":return E.stop()}},M)}));function p(){return m.apply(this,arguments)}return p}()}}}},55430:function(i,n,e){e.r(n),e.d(n,{demos:function(){return p}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(26930),g=e(60228),u=e(72109),c=e(89753),s=e(4966),o=e(84434),a=e(82159),m=e(74106),p={"docs-entities-pc-03-regist-d-demo-03-regist-d":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,29127))})),asset:{type:"BLOCK",id:"docs-entities-pc-03-regist-d-demo-03-regist-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(3415).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form/rules":g,"@by-l/react-form/useForm":u,"@by-l/react-form/useForm/decorator":c,antd:s,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":a,"/Users/boyang/code/react/react-form/src/examples/index.css":m},renderOpts:{compile:function(){var M=v()(r()().mark(function I(){var U,E=arguments;return r()().wrap(function(D){for(;;)switch(D.prev=D.next){case 0:return D.next=2,e.e(417).then(e.bind(e,78235));case 2:return D.abrupt("return",(U=D.sent).default.apply(U,E));case 3:case"end":return D.stop()}},I)}));function y(){return M.apply(this,arguments)}return y}()}}}},69198:function(i,n,e){e.r(n),e.d(n,{demos:function(){return a}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(7146),g=e(84347),u=e(4966),c=e(84434),s=e(82159),o=e(74106),a={"docs-entities-pc-03-regist-demo-03-regist":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,71592))})),asset:{type:"BLOCK",id:"docs-entities-pc-03-regist-demo-03-regist",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(76970).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":g,antd:u,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":c,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":s,"/Users/boyang/code/react/react-form/src/examples/index.css":o},renderOpts:{compile:function(){var m=v()(r()().mark(function M(){var y,I=arguments;return r()().wrap(function(E){for(;;)switch(E.prev=E.next){case 0:return E.next=2,e.e(417).then(e.bind(e,78235));case 2:return E.abrupt("return",(y=E.sent).default.apply(y,I));case 3:case"end":return E.stop()}},M)}));function p(){return m.apply(this,arguments)}return p}()}}}},59349:function(i,n,e){e.r(n),e.d(n,{demos:function(){return p}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(13857),g=e(60228),u=e(72109),c=e(89753),s=e(4966),o=e(84434),a=e(82159),m=e(74106),p={"docs-entities-pc-04-linkage-d-demo-04-linkage-d":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,63520))})),asset:{type:"BLOCK",id:"docs-entities-pc-04-linkage-d-demo-04-linkage-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(51574).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form/rules":g,"@by-l/react-form/useForm":u,"@by-l/react-form/useForm/decorator":c,antd:s,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":a,"/Users/boyang/code/react/react-form/src/examples/index.css":m},renderOpts:{compile:function(){var M=v()(r()().mark(function I(){var U,E=arguments;return r()().wrap(function(D){for(;;)switch(D.prev=D.next){case 0:return D.next=2,e.e(417).then(e.bind(e,78235));case 2:return D.abrupt("return",(U=D.sent).default.apply(U,E));case 3:case"end":return D.stop()}},I)}));function y(){return M.apply(this,arguments)}return y}()}}}},28919:function(i,n,e){e.r(n),e.d(n,{demos:function(){return a}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(75271),l=e(66254),g=e(84347),u=e(4966),c=e(84434),s=e(82159),o=e(74106),a={"docs-entities-pc-04-linkage-demo-04-linkage":{component:f.memo(f.lazy(function(){return e.e(433).then(e.bind(e,32659))})),asset:{type:"BLOCK",id:"docs-entities-pc-04-linkage-demo-04-linkage",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(63823).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":g,antd:u,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":c,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":s,"/Users/boyang/code/react/react-form/src/examples/index.css":o},renderOpts:{compile:function(){var m=v()(r()().mark(function M(){var y,I=arguments;return r()().wrap(function(E){for(;;)switch(E.prev=E.next){case 0:return E.next=2,e.e(417).then(e.bind(e,78235));case 2:return E.abrupt("return",(y=E.sent).default.apply(y,I));case 3:case"end":return E.stop()}},M)}));function p(){return m.apply(this,arguments)}return p}()}}}},70370:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return p}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(71086),u=e(84347),c=e(4966),s=e(82159),o=e(94279),a=e(84434),m=e(74106),p={"docs-entities-pc-05-subform-d-demo-05-subform-d":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,57565))})),asset:{type:"BLOCK",id:"docs-entities-pc-05-subform-d-demo-05-subform-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(99383).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../index.css":{type:"FILE",value:e(82415).Z},react:{type:"NPM",value:"18.3.1"}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":a,"/Users/boyang/code/react/react-form/src/examples/index.css":m,react:_||(_=e.t(l,2))},renderOpts:{compile:function(){var M=f()(t()().mark(function I(){var U,E=arguments;return t()().wrap(function(D){for(;;)switch(D.prev=D.next){case 0:return D.next=2,e.e(417).then(e.bind(e,78235));case 2:return D.abrupt("return",(U=D.sent).default.apply(U,E));case 3:case"end":return D.stop()}},I)}));function y(){return M.apply(this,arguments)}return y}()}}}},65537:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return p}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(18531),u=e(84347),c=e(4966),s=e(84434),o=e(94279),a=e(82159),m=e(74106),p={"docs-entities-pc-05-subform-demo-05-subform":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,99999))})),asset:{type:"BLOCK",id:"docs-entities-pc-05-subform-demo-05-subform",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(8618).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},react:{type:"NPM",value:"18.3.1"},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":a,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/index.css":m},renderOpts:{compile:function(){var M=f()(t()().mark(function I(){var U,E=arguments;return t()().wrap(function(D){for(;;)switch(D.prev=D.next){case 0:return D.next=2,e.e(417).then(e.bind(e,78235));case 2:return D.abrupt("return",(U=D.sent).default.apply(U,E));case 3:case"end":return D.stop()}},I)}));function y(){return M.apply(this,arguments)}return y}()}}}},53885:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return y}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(96290),u=e(84347),c=e(4966),s=e(84434),o=e(24233),a=e(40889),m=e(82159),p=e(94279),M=e(74106),y={"docs-entities-pc-06-formlist-d-demo-06-formlist01":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,66304))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-d-demo-06-formlist01",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(51899).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":o},renderOpts:{compile:function(){var I=f()(t()().mark(function E(){var b,D=arguments;return t()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:return d.next=2,e.e(417).then(e.bind(e,78235));case 2:return d.abrupt("return",(b=d.sent).default.apply(b,D));case 3:case"end":return d.stop()}},E)}));function U(){return I.apply(this,arguments)}return U}()}},"docs-entities-pc-06-formlist-d-demo-06-formlist02":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,98645))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-d-demo-06-formlist02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(89552).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":o},renderOpts:{compile:function(){var I=f()(t()().mark(function E(){var b,D=arguments;return t()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:return d.next=2,e.e(417).then(e.bind(e,78235));case 2:return d.abrupt("return",(b=d.sent).default.apply(b,D));case 3:case"end":return d.stop()}},E)}));function U(){return I.apply(this,arguments)}return U}()}},"docs-entities-pc-06-formlist-d-demo-06-formlist03-d":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,25111))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-d-demo-06-formlist03-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(46222).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../compoment/nameListSimple.tsx":{type:"FILE",value:e(26242).Z},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"../index.css":{type:"FILE",value:e(82415).Z},react:{type:"NPM",value:"18.3.1"},"./ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/nameListSimple.tsx":a,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":m,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":p,"/Users/boyang/code/react/react-form/src/examples/index.css":M,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":o},renderOpts:{compile:function(){var I=f()(t()().mark(function E(){var b,D=arguments;return t()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:return d.next=2,e.e(417).then(e.bind(e,78235));case 2:return d.abrupt("return",(b=d.sent).default.apply(b,D));case 3:case"end":return d.stop()}},E)}));function U(){return I.apply(this,arguments)}return U}()}}}},20731:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return d}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(14441),u=e(84347),c=e(4966),s=e(24233),o=e(84434),a=e(82159),m=e(60228),p=e(94279),M=e(40889),y=e(72109),I=e(74106),U=e(82421),E=e(72023),b=e(8541),D=e(17684),W=e(98144),d={"docs-entities-pc-06-formlist-demo-06-formlist01":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,66304))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-demo-06-formlist01",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(51899).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z},"./utils.tsx":{type:"FILE",value:e(82150).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":s,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":o},renderOpts:{compile:function(){var N=f()(t()().mark(function K(){var B,C=arguments;return t()().wrap(function(P){for(;;)switch(P.prev=P.next){case 0:return P.next=2,e.e(417).then(e.bind(e,78235));case 2:return P.abrupt("return",(B=P.sent).default.apply(B,C));case 3:case"end":return P.stop()}},K)}));function R(){return N.apply(this,arguments)}return R}()}},"docs-entities-pc-06-formlist-demo-06-formlist02":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,98645))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-demo-06-formlist02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(89552).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":s},renderOpts:{compile:function(){var N=f()(t()().mark(function K(){var B,C=arguments;return t()().wrap(function(P){for(;;)switch(P.prev=P.next){case 0:return P.next=2,e.e(417).then(e.bind(e,78235));case 2:return P.abrupt("return",(B=P.sent).default.apply(B,C));case 3:case"end":return P.stop()}},K)}));function R(){return N.apply(this,arguments)}return R}()}},"docs-entities-pc-06-formlist-demo-06-formlist03":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,27597))})),asset:{type:"BLOCK",id:"docs-entities-pc-06-formlist-demo-06-formlist03",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(9323).Z},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../rules.ts":{type:"FILE",value:e(40909).Z},"./compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"./compoment/nameListSimple.tsx":{type:"FILE",value:e(26242).Z},"../useForm.ts":{type:"FILE",value:e(70899).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},react:{type:"NPM",value:"18.3.1"},"../index.css":{type:"FILE",value:e(82415).Z},"./ListItem.tsx":{type:"FILE",value:e(91761).Z},"../hooks/useStatePro.ts":{type:"FILE",value:e(17431).Z},"../tools.ts":{type:"FILE",value:e(43486).Z},"./useCheck.ts":{type:"FILE",value:e(50721).Z},"./useBind.ts":{type:"FILE",value:e(37684).Z},"./useFormData.ts":{type:"FILE",value:e(44725).Z}},entry:"index.tsx"},context:{antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":a,"/Users/boyang/code/react/react-form/src/rules.ts":m,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":p,"/Users/boyang/code/react/react-form/src/examples/compoment/nameListSimple.tsx":M,"/Users/boyang/code/react/react-form/src/useForm/index.ts":y,"@by-l/react-form":u,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/index.css":I,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":s,"/Users/boyang/code/react/react-form/src/hooks/useStatePro.ts":U,"/Users/boyang/code/react/react-form/src/tools.ts":E,"/Users/boyang/code/react/react-form/src/useForm/useCheck.ts":b,"/Users/boyang/code/react/react-form/src/useForm/useBind.ts":D,"/Users/boyang/code/react/react-form/src/useForm/useFormData.ts":W},renderOpts:{compile:function(){var N=f()(t()().mark(function K(){var B,C=arguments;return t()().wrap(function(P){for(;;)switch(P.prev=P.next){case 0:return P.next=2,e.e(417).then(e.bind(e,78235));case 2:return P.abrupt("return",(B=P.sent).default.apply(B,C));case 3:case"end":return P.stop()}},K)}));function R(){return N.apply(this,arguments)}return R}()}}}},1143:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return y}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(11593),u=e(84347),c=e(4966),s=e(84434),o=e(94279),a=e(24233),m=e(74106),p=e(82159),M=e(70237),y={"docs-entities-pc-07-form-list-plus-d-demo-07-formlistplus":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,52265))})),asset:{type:"BLOCK",id:"docs-entities-pc-07-form-list-plus-d-demo-07-formlistplus",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(3071).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z},react:{type:"NPM",value:"18.3.1"},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":a,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/index.css":m},renderOpts:{compile:function(){var I=f()(t()().mark(function E(){var b,D=arguments;return t()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:return d.next=2,e.e(417).then(e.bind(e,78235));case 2:return d.abrupt("return",(b=d.sent).default.apply(b,D));case 3:case"end":return d.stop()}},E)}));function U(){return I.apply(this,arguments)}return U}()}},"docs-entities-pc-07-form-list-plus-d-demo-07-formlistplus02-d":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,31275))})),asset:{type:"BLOCK",id:"docs-entities-pc-07-form-list-plus-d-demo-07-formlistplus02-d",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(25147).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"../utils.tsx":{type:"FILE",value:e(82150).Z},"../compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"../compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"../compoment/nameList.tsx":{type:"FILE",value:e(8790).Z},"../index.css":{type:"FILE",value:e(82415).Z},react:{type:"NPM",value:"18.3.1"},"./ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":p,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/nameList.tsx":M,"/Users/boyang/code/react/react-form/src/examples/index.css":m,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":a},renderOpts:{compile:function(){var I=f()(t()().mark(function E(){var b,D=arguments;return t()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:return d.next=2,e.e(417).then(e.bind(e,78235));case 2:return d.abrupt("return",(b=d.sent).default.apply(b,D));case 3:case"end":return d.stop()}},E)}));function U(){return I.apply(this,arguments)}return U}()}}}},41429:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return d}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(25997),u=e(84347),c=e(4966),s=e(84434),o=e(94279),a=e(24233),m=e(74106),p=e(60228),M=e(72109),y=e(82159),I=e(70237),U=e(82421),E=e(17684),b=e(8541),D=e(72023),W=e(98144),d={"docs-entities-pc-07-form-list-plus-demo-07-formlistplus":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,52265))})),asset:{type:"BLOCK",id:"docs-entities-pc-07-form-list-plus-demo-07-formlistplus",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(3071).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"./compoment/ListItem.tsx":{type:"FILE",value:e(91761).Z},react:{type:"NPM",value:"18.3.1"},"../index.css":{type:"FILE",value:e(82415).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":a,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/index.css":m},renderOpts:{compile:function(){var N=f()(t()().mark(function K(){var B,C=arguments;return t()().wrap(function(P){for(;;)switch(P.prev=P.next){case 0:return P.next=2,e.e(417).then(e.bind(e,78235));case 2:return P.abrupt("return",(B=P.sent).default.apply(B,C));case 3:case"end":return P.stop()}},K)}));function R(){return N.apply(this,arguments)}return R}()}},"docs-entities-pc-07-form-list-plus-demo-07-formlistplus02":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,53057))})),asset:{type:"BLOCK",id:"docs-entities-pc-07-form-list-plus-demo-07-formlistplus02",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(66907).Z},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"../rules.ts":{type:"FILE",value:e(40909).Z},"../useForm.ts":{type:"FILE",value:e(70899).Z},"./compoment/FormItem.tsx":{type:"FILE",value:e(44616).Z},"./compoment/FullName.tsx":{type:"FILE",value:e(21436).Z},"./compoment/nameList.tsx":{type:"FILE",value:e(8790).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},react:{type:"NPM",value:"18.3.1"},"../index.css":{type:"FILE",value:e(82415).Z},"../hooks/useStatePro.ts":{type:"FILE",value:e(17431).Z},"./useBind.ts":{type:"FILE",value:e(37684).Z},"./useCheck.ts":{type:"FILE",value:e(50721).Z},"../tools.ts":{type:"FILE",value:e(43486).Z},"./useFormData.ts":{type:"FILE",value:e(44725).Z},"./ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/rules.ts":p,"/Users/boyang/code/react/react-form/src/useForm/index.ts":M,"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":y,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/nameList.tsx":I,"@by-l/react-form":u,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/index.css":m,"/Users/boyang/code/react/react-form/src/hooks/useStatePro.ts":U,"/Users/boyang/code/react/react-form/src/useForm/useBind.ts":E,"/Users/boyang/code/react/react-form/src/useForm/useCheck.ts":b,"/Users/boyang/code/react/react-form/src/tools.ts":D,"/Users/boyang/code/react/react-form/src/useForm/useFormData.ts":W,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":a},renderOpts:{compile:function(){var N=f()(t()().mark(function K(){var B,C=arguments;return t()().wrap(function(P){for(;;)switch(P.prev=P.next){case 0:return P.next=2,e.e(417).then(e.bind(e,78235));case 2:return P.abrupt("return",(B=P.sent).default.apply(B,C));case 3:case"end":return P.stop()}},K)}));function R(){return N.apply(this,arguments)}return R}()}}}},31617:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return U}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(20834),u=e(84347),c=e(4966),s=e(84434),o=e(1656),a=e(50175),m=e(82159),p=e(94279),M=e(70237),y=e(74106),I=e(24233),U={"docs-entities-pc-08-form-list-pro-d-demo-08-formlistpro":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,10120))})),asset:{type:"BLOCK",id:"docs-entities-pc-08-form-list-pro-d-demo-08-formlistpro",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(41825).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/Card.tsx":{type:"FILE",value:e(47428).Z},"./compoment/ClassForm.tsx":{type:"FILE",value:e(16930).Z},react:{type:"NPM",value:"18.3.1"},"./FormItem.tsx":{type:"FILE",value:e(44616).Z},"./FullName.tsx":{type:"FILE",value:e(21436).Z},"./nameList.tsx":{type:"FILE",value:e(8790).Z},"../index.css":{type:"FILE",value:e(82415).Z},"./ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/Card.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/ClassForm.tsx":a,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":m,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":p,"/Users/boyang/code/react/react-form/src/examples/compoment/nameList.tsx":M,"/Users/boyang/code/react/react-form/src/examples/index.css":y,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":I},renderOpts:{compile:function(){var E=f()(t()().mark(function D(){var W,d=arguments;return t()().wrap(function(R){for(;;)switch(R.prev=R.next){case 0:return R.next=2,e.e(417).then(e.bind(e,78235));case 2:return R.abrupt("return",(W=R.sent).default.apply(W,d));case 3:case"end":return R.stop()}},D)}));function b(){return E.apply(this,arguments)}return b}()}}}},6600:function(i,n,e){var _;e.r(n),e.d(n,{demos:function(){return U}});var r=e(90228),t=e.n(r),v=e(87999),f=e.n(v),l=e(75271),g=e(48861),u=e(84347),c=e(4966),s=e(84434),o=e(1656),a=e(50175),m=e(82159),p=e(94279),M=e(70237),y=e(74106),I=e(24233),U={"docs-entities-pc-08-form-list-pro-demo-08-formlistpro":{component:l.memo(l.lazy(function(){return e.e(433).then(e.bind(e,10120))})),asset:{type:"BLOCK",id:"docs-entities-pc-08-form-list-pro-demo-08-formlistpro",refAtomIds:[],dependencies:{"index.tsx":{type:"FILE",value:e(41825).Z},"@by-l/react-form":{type:"NPM",value:"0.0.1"},antd:{type:"NPM",value:"5.20.6"},"./utils.tsx":{type:"FILE",value:e(82150).Z},"./compoment/Card.tsx":{type:"FILE",value:e(47428).Z},"./compoment/ClassForm.tsx":{type:"FILE",value:e(16930).Z},react:{type:"NPM",value:"18.3.1"},"./FormItem.tsx":{type:"FILE",value:e(44616).Z},"./FullName.tsx":{type:"FILE",value:e(21436).Z},"./nameList.tsx":{type:"FILE",value:e(8790).Z},"../index.css":{type:"FILE",value:e(82415).Z},"./ListItem.tsx":{type:"FILE",value:e(91761).Z}},entry:"index.tsx"},context:{"@by-l/react-form":u,antd:c,"/Users/boyang/code/react/react-form/src/examples/utils/index.tsx":s,"/Users/boyang/code/react/react-form/src/examples/compoment/Card.tsx":o,"/Users/boyang/code/react/react-form/src/examples/compoment/ClassForm.tsx":a,react:_||(_=e.t(l,2)),"/Users/boyang/code/react/react-form/src/examples/compoment/FormItem.tsx":m,"/Users/boyang/code/react/react-form/src/examples/compoment/FullName.tsx":p,"/Users/boyang/code/react/react-form/src/examples/compoment/nameList.tsx":M,"/Users/boyang/code/react/react-form/src/examples/index.css":y,"/Users/boyang/code/react/react-form/src/examples/compoment/ListItem.tsx":I},renderOpts:{compile:function(){var E=f()(t()().mark(function D(){var W,d=arguments;return t()().wrap(function(R){for(;;)switch(R.prev=R.next){case 0:return R.next=2,e.e(417).then(e.bind(e,78235));case 2:return R.abrupt("return",(W=R.sent).default.apply(W,d));case 3:case"end":return R.stop()}},D)}));function b(){return E.apply(this,arguments)}return b}()}}}},80023:function(i,n,e){e.r(n),e.d(n,{demos:function(){return t}});var _=e(75271),r=e(22742),t={}},1656:function(i,n,e){e.r(n),e.d(n,{MyCard:function(){return f}});var _=e(75271),r=e(22476),t=e(33407),v=e(52676),f=function(g){var u=g.formItem,c=g.onDelete;return(0,v.jsx)(r.Z,{extra:(0,v.jsx)(t.ZP,{type:"link",onClick:c,children:"\u79FB\u9664"}),children:u})}},50175:function(i,n,e){e.r(n),e.d(n,{ClassForm:function(){return A}});var _=e(7278),r=e.n(_),t=e(17069),v=e.n(t),f=e(25298),l=e.n(f),g=e(82092),u=e.n(g),c=e(33766),s=e.n(c),o=e(69217),a=e.n(o),m=e(84347),p=e(83887),M=e(94279),y=e(70237),I=e(82159),U=e(75271),E=e(52676),b,D,W,d,N,R,K,B,C,h,P,Z,L=(b=(0,m.formItem)((0,E.jsx)(p.Z,{placeholder:"class"})),D=(0,m.label)("\u73ED\u7EA7"),W=(0,m.rules)((0,m.required)()),d=(0,m.subForm)((0,E.jsx)(M.FullName,{})),N=(0,m.label)("\u8001\u5E08"),R=(0,m.formList)((0,E.jsx)(y.NameList,{})),K=(0,m.label)("\u5B66\u751F"),B=(0,m.rules)((0,m.required)("\u6700\u5C111\u4E2A\u5B66\u751F"),(0,m.min)(1,"\u6700\u5C111\u4E2A\u5B66\u751F")),C=v()(function F(){l()(this,F),r()(this,"className",h,this),r()(this,"teacher",P,this),r()(this,"students",Z,this)}),h=s()(C.prototype,"className",[b,D,W],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),P=s()(C.prototype,"teacher",[d,N],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),Z=s()(C.prototype,"students",[R,K,B],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),C),A=function(T){var O=(0,m.useForm)({config:L,onChange:T.onChange,father:T.father});(0,U.useEffect)(function(){O.setFormData(T.value)},[T.value]);var S=O.items.map(function(x){return(0,E.jsx)(I.FormItem,{label:x.label,formItem:x.formItem,error:x.error},x.name)});return(0,E.jsx)("div",{children:S})}},82159:function(i,n,e){e.r(n),e.d(n,{FormItem:function(){return t}});var _=e(74106),r=e(52676),t=function(f){var l=f.label,g=f.formItem,u=f.error;return(0,r.jsxs)("div",{className:"container","data-err":u,children:[(0,r.jsx)("div",{className:"label",children:l}),(0,r.jsx)("div",{children:g})]})}},94279:function(i,n,e){e.r(n),e.d(n,{FullName:function(){return B}});var _=e(7278),r=e.n(_),t=e(17069),v=e.n(t),f=e(25298),l=e.n(f),g=e(82092),u=e.n(g),c=e(33766),s=e.n(c),o=e(69217),a=e.n(o),m=e(83887),p=e(41115),M=e(75271),y=e(84347),I=e(74106),U=e(52676),E,b,D,W,d,N,R,K=(E=(0,y.formItem)((0,U.jsx)(m.Z,{placeholder:"first name"})),b=(0,y.rules)((0,y.required)("firstName\u4E0D\u80FD\u4E3A\u7A7A")),D=(0,y.formItem)((0,U.jsx)(m.Z,{placeholder:"last name"})),W=(0,y.rules)((0,y.required)("lastName\u4E0D\u80FD\u4E3A\u7A7A")),d=v()(function C(){l()(this,C),r()(this,"firstName",N,this),r()(this,"lastName",R,this)}),N=s()(d.prototype,"firstName",[E,b],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),R=s()(d.prototype,"lastName",[D,W],{configurable:!0,enumerable:!0,writable:!0,initializer:null}),d),B=function(h){var P=(0,y.useForm)({config:K,onChange:h.onChange,father:h.father});(0,M.useEffect)(function(){P.setFormData(h.value)},[h.value]);var Z=P.items.map(function(L){return(0,U.jsx)("div",{className:"name","data-err":L.error,children:L.formItem},L.name)});return(0,U.jsx)(p.Z,{gap:9,children:Z})}},24233:function(i,n,e){e.r(n),e.d(n,{ListItem:function(){return v}});var _=e(41115),r=e(33407),t=e(52676),v=function(l){var g=l.formItem,u=l.error,c=l.onDelete;return(0,t.jsxs)(_.Z,{className:"item","data-err":u,align:"center",gap:3,children:[g,(0,t.jsx)(r.ZP,{onClick:c,size:"small",style:{color:"#999"},type:"text",children:"\u5220\u9664"})]})}},70237:function(i,n,e){e.r(n),e.d(n,{NameList:function(){return c},nameListConfig:function(){return u}});var _=e(84347),r=e(41115),t=e(33407),v=e(94279),f=e(24233),l=e(75271),g=e(52676),u={subForm:(0,g.jsx)(v.FullName,{})},c=function(o){var a=(0,_.useFormList)({father:o.father,config:u,onChange:o.onChange});(0,l.useEffect)(function(){a.setFormList(o.value)},[o.value]);var m=a.items.map(function(p,M){return(0,g.jsx)(f.ListItem,{formItem:p.formItem,error:p.error,onDelete:function(){return a.remove(M)}},p.name)});return(0,g.jsxs)(r.Z,{vertical:!0,gap:32,style:{width:300},children:[m,(0,g.jsx)(t.ZP,{onClick:function(){return a.push()},children:"\u6DFB\u52A0"})]})}},40889:function(i,n,e){e.r(n),e.d(n,{NameListSimple:function(){return c},nameListConfig:function(){return u}});var _=e(84347),r=e(83887),t=e(41115),v=e(33407),f=e(24233),l=e(75271),g=e(52676),u={formItem:(0,g.jsx)(r.Z,{placeholder:"name..."}),rules:[(0,_.required)()]},c=function(o){var a=(0,_.useFormList)({father:o.father,config:u,onChange:o.onChange});(0,l.useEffect)(function(){a.setFormList(o.value)},[o.value]);var m=a.items.map(function(p,M){return(0,g.jsx)(f.ListItem,{formItem:p.formItem,error:p.error,onDelete:function(){return a.remove(M)}},p.name)});return(0,g.jsxs)(t.Z,{vertical:!0,gap:32,style:{width:300},children:[m,(0,g.jsx)(v.ZP,{onClick:function(){return a.push()},children:"\u6DFB\u52A0"})]})}},84434:function(i,n,e){e.r(n),e.d(n,{msg:function(){return _}});function _(r){alert(JSON.stringify(r,function(t,v){return v===void 0?"undefined":v},2))}},82421:function(i,n,e){e.r(n),e.d(n,{useStatePro:function(){return v}});var _=e(48305),r=e.n(_),t=e(75271),v=function(g){var u=(0,t.useState)(g),c=r()(u,2),s=c[0],o=c[1],a=(0,t.useRef)(g),m=function(){return a.current},p=function(y){f(y)?o(function(I){var U=y(I);return a.current=U,U}):(o(y),a.current=y)};return[s,p,m]};function f(l){return typeof l=="function"}},84347:function(i,n,e){e.r(n),e.d(n,{email:function(){return K.email},formItem:function(){return B.formItem},formList:function(){return B.formList},idCard:function(){return K.idCard},label:function(){return B.label},max:function(){return K.max},min:function(){return K.min},nickName:function(){return K.nickName},password:function(){return K.password},phone:function(){return K.phone},required:function(){return K.required},rules:function(){return B.rules},show:function(){return B.show},subForm:function(){return B.subForm},useForm:function(){return _.useForm},useFormList:function(){return d},valueName:function(){return B.valueName}});var _=e(72109),r=e(90228),t=e.n(r),v=e(15558),f=e.n(v),l=e(87999),g=e.n(l),u=e(48305),c=e.n(u),s=e(75271),o=e(82421),a=e(72023),m=e(82092),p=e.n(m),M=function(h,P,Z,L){var A=c()(P,3),F=A[0],T=A[1],O=A[2],S=c()(Z,3),x=S[0],H=S[1],z=S[2],Y=h.config,j=function(X){return function(){var w=g()(t()().mark(function re(ae){var te,q,ne,oe;return t()().wrap(function($){for(;;)switch($.prev=$.next){case 0:return te=O(),te[X]=(0,a.getValue)(ae,Y.valueName),T(te),h.onChange&&h.onChange(te,X),q=Y.rules||[],$.next=7,L.checkItem(te[X],q);case 7:ne=$.sent,oe=z(),oe[X]=ne,H(f()(oe));case 11:case"end":return $.stop()}},re)}));return function(re){return w.apply(this,arguments)}}()},_e=function(X){var w=Y.valueName,re=w===void 0?"value":w,ae=p()(p()(p()(p()({},re,F[X]),"onChange",j(X)),"name",X),"key",X);Y.formItem||(ae.father=h.father||L.subscrible);var te=(0,a.getItem)(Y);return(0,s.cloneElement)(te,ae)};return(0,s.useMemo)(function(){for(var ee=[],X=F||[],w=0;w<X.length;w++)ee.push({name:w,formItem:_e(w),label:Y.label,error:x[w]});return ee},[F,x])},y=e(335),I=e.n(y);function U(C,h){var P=(0,s.useRef)(h);return(0,s.useEffect)(function(){P.current=h},[h]),function(){for(var Z=arguments.length,L=new Array(Z),A=0;A<Z;A++)L[A]=arguments[A];return C(P.current,L)}}var E=function(h,P,Z,L){var A=c()(P,2),F=A[0],T=A[1],O=c()(Z,2),S=O[0],x=O[1],H=c()(L,2),z=H[0],Y=H[1],j=h.config,_e=j.rules,ee=_e===void 0?[]:_e,X=j.listRules,w=U(function(){var q=g()(t()().mark(function ne(oe){var se,$,J,Q,V,k;return t()().wrap(function(G){for(;;)switch(G.prev=G.next){case 0:if(se=oe.arr,$=!1,!X){G.next=8;break}return G.next=5,b(se,X);case 5:J=G.sent,J&&($=!0),Y(J);case 8:if(!ee){G.next=21;break}Q=[],V=0;case 11:if(!(V<se.length)){G.next=20;break}return G.next=14,b(se[V],ee);case 14:k=G.sent,k&&($=!0),Q[V]=k;case 17:V++,G.next=11;break;case 20:x(Q);case 21:return G.abrupt("return",{hasError:$,error:J,errorList:S,firstError:W(J,Q)});case 22:case"end":return G.stop()}},ne)}));return function(ne){return q.apply(this,arguments)}}(),{arr:F}),re=(0,s.useRef)([w]),ae=function(){var q=g()(t()().mark(function ne(){var oe,se,$,J,Q;return t()().wrap(function(k){for(;;)switch(k.prev=k.next){case 0:oe=!1,$=0;case 2:if(!($<re.current.length)){k.next=12;break}return J=re.current[$],k.next=6,J();case 6:Q=k.sent,Q.hasError&&(oe=!0),Q.hasError&&!se&&(se=Q.firstError);case 9:$++,k.next=2;break;case 12:return k.abrupt("return",{hasError:oe,firstError:se});case 13:case"end":return k.stop()}},ne)}));return function(){return q.apply(this,arguments)}}();function te(q){return re.current.push(q),function(){var ne=re.current.indexOf(q);re.current.splice(ne,1)}}return(0,s.useEffect)(function(){var q=h.father;if((0,a.isFunction)(q)!==!1){var ne=q(w);return function(){return ne()}}},[]),{checkItem:b,checkForm:w,submit:ae,subscrible:te}};function b(C,h){return D.apply(this,arguments)}function D(){return D=g()(t()().mark(function C(h,P){var Z,L,A,F;return t()().wrap(function(O){for(;;)switch(O.prev=O.next){case 0:Z=void 0,L=I()(P),O.prev=2,L.s();case 4:if((A=L.n()).done){O.next=17;break}return F=A.value,O.prev=6,O.next=9,F(h);case 9:O.next=15;break;case 11:return O.prev=11,O.t0=O.catch(6),Z=O.t0,O.abrupt("break",17);case 15:O.next=4;break;case 17:O.next=22;break;case 19:O.prev=19,O.t1=O.catch(2),L.e(O.t1);case 22:return O.prev=22,L.f(),O.finish(22);case 25:return O.abrupt("return",Z);case 26:case"end":return O.stop()}},C,null,[[2,19,22,25],[6,11]])})),D.apply(this,arguments)}function W(C,h){if(C)return C;var P=I()(h),Z;try{for(P.s();!(Z=P.n()).done;){var L=Z.value;if(L)return L}}catch(A){P.e(A)}finally{P.f()}}var d=function(h){var P=h.config,Z=(0,o.useStatePro)(N(h)),L=c()(Z,3),A=L[0],F=L[1],T=L[2],O=(0,o.useStatePro)(R(h)),S=c()(O,3),x=S[0],H=S[1],z=S[2],Y=(0,s.useState)(""),j=c()(Y,2),_e=j[0],ee=j[1],X=E(h,[A,F],[x,H],[_e,ee]),w=M(h,[A,F,T],[x,H,z],X),re=function(J){F(J||[])},ae=function(){F(N(h)),H([]),ee("")};function te(){return q.apply(this,arguments)}function q(){return q=g()(t()().mark(function $(){var J;return t()().wrap(function(V){for(;;)switch(V.prev=V.next){case 0:return V.next=2,X.submit();case 2:J=V.sent,J.hasError?h.onFail&&h.onFail(J.firstError):h.onSuccess&&h.onSuccess(A);case 4:case"end":return V.stop()}},$)})),q.apply(this,arguments)}var ne=function(){var $=g()(t()().mark(function J(Q){var V;return t()().wrap(function(me){for(;;)switch(me.prev=me.next){case 0:return A.splice(Q,1),F(f()(A)),h.onChange&&h.onChange(A),x.splice(Q,1),H(f()(x)),me.next=7,X.checkItem(A,P.listRules||[]);case 7:V=me.sent,ee(V);case 9:case"end":return me.stop()}},J)}));return function(Q){return $.apply(this,arguments)}}(),oe=function(){var $=g()(t()().mark(function J(Q){var V,k;return t()().wrap(function(G){for(;;)switch(G.prev=G.next){case 0:return V=[].concat(f()(A),[Q]),F(V),h.onChange&&h.onChange(V),H([].concat(f()(x),[void 0])),G.next=6,X.checkItem(V,P.listRules||[]);case 6:k=G.sent,ee(k);case 8:case"end":return G.stop()}},J)}));return function(Q){return $.apply(this,arguments)}}(),se=function(){var $=g()(t()().mark(function J(Q){var V,k;return t()().wrap(function(G){for(;;)switch(G.prev=G.next){case 0:return V=[Q].concat(f()(A)),F(V),h.onChange&&h.onChange(V),H([void 0].concat(f()(x))),G.next=6,X.checkItem(V,P.listRules||[]);case 6:k=G.sent,ee(k);case 8:case"end":return G.stop()}},J)}));return function(Q){return $.apply(this,arguments)}}();return{items:w,submit:te,checkFormList:X.checkForm,reset:ae,setFormList:re,setErrList:H,setErr:ee,push:oe,unshift:se,remove:ne,error:_e,getErrList:z,getFormData:T}};function N(C){return C.config.initValue=C.initialValue||[void 0],C.config.initValue}function R(C){var h=C.initialValue;return(0,a.isArray)(h)?h.map(function(){}):[void 0]}var K=e(60228),B=e(89753)},60228:function(i,n,e){e.r(n),e.d(n,{email:function(){return l},idCard:function(){return u},max:function(){return r},min:function(){return t},nickName:function(){return v},password:function(){return f},phone:function(){return g},required:function(){return _}});var _=function(s){return function(o,a){if(!o)throw s||"\u4E0D\u80FD\u4E3A\u7A7A"}},r=function(s,o){return function(a){if(a&&a.length>s)throw o||"\u957F\u5EA6\u4E0D\u80FD\u5927\u4E8E".concat(s)}},t=function(s,o){return function(a){if(a&&a.length<s)throw o||"\u957F\u5EA6\u4E0D\u80FD\u5C0F\u4E8E".concat(s)}},v=function(s){return function(o){if(o){var a=s||"\u8BF7\u586B\u5199\u4E2D\u6587\u6216\u5B57\u6BCD\u6216\u6570\u5B57\u6216\u4E0B\u5212\u7EBF",m=/^[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(o);if(m===!1)throw a}}},f=function(){return function(s){if(s){var o=/^(?=.*\d).{1,}$/.test(s);if(o===!1)throw"\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u6570\u5B57";var a=/^(?=.*[a-zA-Z]).{1,}$/.test(s);if(a===!1)throw"\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u5B57\u6BCD";var m=/^(?=.*[@$!%*?&]).{1,}$/.test(s);if(m===!1)throw"\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u7279\u6B8A\u7B26\u53F7@$!%*?&"}}},l=function(s){return function(o){if(o){var a=s||"\u8BF7\u8F93\u5165\u6B63\u786Eemail\u5730\u5740",m=/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(o);if(m===!1)throw a}}},g=function(s){return function(o){if(o){var a=s||"\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u624B\u673A\u53F7\u7801",m=/^1[3456789]\d{9}$/.test(o);if(m===!1)throw a}}},u=function(s){return function(o){if(o){var a=s||"\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u8EAB\u4EFD\u8BC1\u53F7\u7801",m=/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(o);if(m===!1)throw a}}}},72023:function(i,n,e){e.r(n),e.d(n,{createName:function(){return f},getItem:function(){return _},getValue:function(){return t},initData:function(){return r},isArray:function(){return g},isFunction:function(){return l}});function _(u){var c=u.subForm,s=u.formList,o=u.formItem;return c||s||o}function r(u){var c=u.config,s=u.initialValue,o={};for(var a in s)c[a].initValue=s[a];for(var m in c)o[m]=c[m].initValue;return o}function t(u){var c=arguments.length>1&&arguments[1]!==void 0?arguments[1]:"value";return!u||!u.target?u:u.target[c]}var v=0;function f(){var u=new Date().getTime();return"".concat(u,"-").concat(v++)}function l(u){return typeof u=="function"}function g(u){return Array.isArray(u)}},89753:function(i,n,e){e.r(n),e.d(n,{formItem:function(){return f},formList:function(){return g},label:function(){return t},rules:function(){return v},show:function(){return c},subForm:function(){return l},valueName:function(){return u}});var _=e(48305),r=e.n(_),t=function(a){return function(m,p){s(m,p,["label",a])}},v=function(){for(var a=arguments.length,m=new Array(a),p=0;p<a;p++)m[p]=arguments[p];return function(M,y){s(M,y,["rules",m])}},f=function(a){return function(m,p){s(m,p,["formItem",a])}},l=function(a){return function(m,p){s(m,p,["subForm",a])}},g=function(a){return function(m,p){s(m,p,["formList",a])}},u=function(a){return function(m,p){s(m,p,["valueName",a])}},c=function(a){return function(m,p){s(m,p,["show",a])}};function s(o,a,m){var p=r()(m,2),M=p[0],y=p[1];o.config||(o.config={}),o.config[a]||(o.config[a]={}),o.config[a][M]=y}},72109:function(i,n,e){e.r(n),e.d(n,{useForm:function(){return p}});var _=e(90228),r=e.n(_),t=e(87999),v=e.n(t),f=e(26068),l=e.n(f),g=e(48305),u=e.n(g),c=e(72023),s=e(8541),o=e(17684),a=e(98144),m=e(82421),p=function(I){I.config=M(I.config);var U=(0,a.useFormData)(I),E=u()(U,3),b=E[0],D=E[1],W=E[2],d=(0,m.useStatePro)({}),N=u()(d,3),R=N[0],K=N[1],B=N[2],C=(0,s.useCheck)(I,[b,D,W],[R,K,B]),h=(0,o.useBind)(I,[b,D,W],[R,K,B],C),P=function T(O){if(!O){K({});return}return K(function(S){return S[O]=void 0,S}),{clearError:T}},Z=function(O){return D(l()(l()({},b),O)),{clearError:P}},L=function(){D((0,c.initData)(I)),K({})};function A(){return F.apply(this,arguments)}function F(){return F=v()(r()().mark(function T(){var O;return r()().wrap(function(x){for(;;)switch(x.prev=x.next){case 0:return x.next=2,C.submit();case 2:O=x.sent,O.hasError?I.onFail&&I.onFail(O.firstError):I.onSuccess&&I.onSuccess(b);case 4:case"end":return x.stop()}},T)})),F.apply(this,arguments)}return{submit:A,checkForm:C.checkForm,setFormData:Z,setError:K,reset:L,getFormData:b,items:h}};function M(y){return typeof y=="function"?(y.create=function(){return y.that||(y.that=new y),y.that},y.create().config):y}},17684:function(i,n,e){e.r(n),e.d(n,{useBind:function(){return m}});var _=e(82092),r=e.n(_),t=e(90228),v=e.n(t),f=e(26068),l=e.n(f),g=e(87999),u=e.n(g),c=e(48305),s=e.n(c),o=e(75271),a=e(72023),m=function(M,y,I,U){var E=s()(y,3),b=E[0],D=E[1],W=E[2],d=s()(I,3),N=d[0],R=d[1],K=d[2],B=M.config,C=M.father,h=function(L){return function(){var A=u()(v()().mark(function F(T){var O,S,x;return v()().wrap(function(z){for(;;)switch(z.prev=z.next){case 0:return O=W(),O[L]=(0,a.getValue)(T,B[L].valueName),D(O),M.onChange&&M.onChange(O,L),z.next=6,U.checkItem(L,O);case 6:S=z.sent,x=K(),x[L]=S,R(l()({},x));case 10:case"end":return z.stop()}},F)}));return function(F){return A.apply(this,arguments)}}()},P=function(L){var A=B[L].valueName,F=A===void 0?"value":A,T=r()(r()(r()(r()({},F,b[L]),"onChange",h(L)),"name",L),"key",L);B[L].formItem||(T.father=C||U.subscrible);var O=(0,a.getItem)(B[L]);return(0,o.cloneElement)(O,T)};return(0,o.useMemo)(function(){var Z=[];for(var L in b)Z.push({name:L,formItem:P(L),label:B[L].label,error:N[L]});return Z},[b,N])}},8541:function(i,n,e){e.r(n),e.d(n,{useCheck:function(){return o}});var _=e(335),r=e.n(_),t=e(90228),v=e.n(t),f=e(87999),l=e.n(f),g=e(48305),u=e.n(g),c=e(75271),s=e(72023),o=function(M,y,I){var U=u()(y,3),E=U[0],b=U[1],D=U[2],W=u()(I,3),d=W[0],N=W[1],R=W[2],K=M.config,B=M.father,C=function(){var F=l()(v()().mark(function T(){var O,S,x,H,z;return v()().wrap(function(j){for(;;)switch(j.prev=j.next){case 0:O={},S=!1,H=D(),j.t0=v()().keys(H);case 4:if((j.t1=j.t0()).done){j.next=12;break}return z=j.t1.value,j.next=8,P(z,H);case 8:O[z]=j.sent,O[z]&&(S=!0,x||(x=O[z])),j.next=4;break;case 12:return N(O),j.abrupt("return",{hasError:S,error:O,firstError:x});case 14:case"end":return j.stop()}},T)}));return function(){return F.apply(this,arguments)}}(),h=(0,c.useRef)([C]);(0,c.useEffect)(function(){var F=B;if((0,s.isFunction)(F)!==!1){var T=F(C);return function(){return T()}}},[]);var P=function(){var F=l()(v()().mark(function T(O,S){var x,H;return v()().wrap(function(Y){for(;;)switch(Y.prev=Y.next){case 0:return x=K[O].rules||[],Y.next=3,a(O,S,x);case 3:return H=Y.sent,Y.abrupt("return",H);case 5:case"end":return Y.stop()}},T)}));return function(O,S){return F.apply(this,arguments)}}();function Z(){return L.apply(this,arguments)}function L(){return L=l()(v()().mark(function F(){var T,O,S,x,H,z;return v()().wrap(function(j){for(;;)switch(j.prev=j.next){case 0:T=!1,x=0;case 2:if(!(x<h.current.length)){j.next=13;break}return H=h.current[x],j.next=6,H();case 6:z=j.sent,z.hasError&&(T=!0),z.hasError&&!O&&(O=z.firstError),x===0&&(S=z.error);case 10:x++,j.next=2;break;case 13:return j.abrupt("return",{hasError:T,firstError:O,error:S});case 14:case"end":return j.stop()}},F)})),L.apply(this,arguments)}function A(F){return h.current.push(F),function(){var T=h.current.indexOf(F);h.current.splice(T,1)}}return{submit:Z,checkItem:P,checkForm:C,subscrible:A}};function a(p,M,y){return m.apply(this,arguments)}function m(){return m=l()(v()().mark(function p(M,y,I){var U,E,b,D;return v()().wrap(function(d){for(;;)switch(d.prev=d.next){case 0:U=void 0,E=r()(I),d.prev=2,E.s();case 4:if((b=E.n()).done){d.next=17;break}return D=b.value,d.prev=6,d.next=9,D(y[M],y);case 9:d.next=15;break;case 11:return d.prev=11,d.t0=d.catch(6),U=d.t0,d.abrupt("break",17);case 15:d.next=4;break;case 17:d.next=22;break;case 19:d.prev=19,d.t1=d.catch(2),E.e(d.t1);case 22:return d.prev=22,E.f(),d.finish(22);case 25:return d.abrupt("return",U);case 26:case"end":return d.stop()}},p,null,[[2,19,22,25],[6,11]])})),m.apply(this,arguments)}},98144:function(i,n,e){e.r(n),e.d(n,{useFormData:function(){return f}});var _=e(48305),r=e.n(_),t=e(75271),v=e(72023);function f(l){var g=l.config,u=(0,t.useState)((0,v.initData)(l)),c=r()(u,2),s=c[0],o=c[1],a=(0,t.useRef)(s),m=(0,t.useMemo)(function(){var M={};for(var y in g){var I=g[y].show;I&&I(s)===!1||(M[y]=s[y])}return M},[s]);(0,t.useEffect)(function(){a.current=m},[m]);function p(){return a.current}return[m,o,p]}},74106:function(i,n,e){e.r(n)},84131:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(28543);const r=[{value:`npm i @by-l/react-form
`,paraId:0,tocIndex:0},{value:`import { useForm, required, formItem, label, rules } from '@by-l/react-form';

class ConfigImpl {
  @formItem(<Input placeholder="e-mail" />)
  @rules(required('\u8BF7\u586B\u5199\u90AE\u7BB1'))
  email: string;

  @formItem(<Input placeholder="password" type="password" />)
  @rules(required('\u8BF7\u586B\u5199\u5BC6\u7801'))
  password: string;
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => console.log(data),
  });

  return (
    <div>
      {form.items.map((item) => item.formItem)}
      <Button onClick={form.submit}>\u767B\u5F55</Button>
    </div>
  );
};
`,paraId:1,tocIndex:1}]},63838:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(945);const r=[]},66072:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(61091);const r=[]},49404:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(26930);const r=[]},68210:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(7146);const r=[]},50975:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(13857);const r=[]},43010:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(66254);const r=[]},99858:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(71086);const r=[]},14240:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(18531);const r=[]},14090:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(96290);const r=[]},77696:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(14441);const r=[]},80123:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(11593);const r=[]},90393:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(25997);const r=[]},8668:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(20834);const r=[]},81906:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(48861);const r=[]},54322:function(i,n,e){e.r(n),e.d(n,{texts:function(){return r}});var _=e(22742);const r=[{value:`class ConfigImpl {
  @formItem(<Input placeholder='e-mail' />)
  @label('\u90AE\u7BB1')
  @rules(required('\u8BF7\u586B\u5199\u90AE\u7BB1'))
  email: string

  @formItem(<Input placeholder='password' type='password' />)
  @label('\u5BC6\u7801')
  @rules(required('\u8BF7\u586B\u5199\u5BC6\u7801'))
  password: string
}
`,paraId:0}]},67795:function(i,n){n.Z=`import { formItem, required, rules, useForm } from '@by-l/react-form';
import { Button, Flex, Input } from 'antd';
import { msg } from './utils';

class ConfigImpl {
  @formItem(<Input placeholder="e-mail" />)
  @rules(required('\u8BF7\u586B\u5199\u90AE\u7BB1'))
  email: string;

  @formItem(<Input placeholder="password" type="password" />)
  @rules(required('\u8BF7\u586B\u5199\u5BC6\u7801'))
  password: string;
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  return (
    <Flex vertical gap={21} style={{ width: 300 }}>
      {form.items.map((item) => item.formItem)}
      <Button onClick={form.submit}>\u767B\u5F55</Button>
    </Flex>
  );
};
`},59254:function(i,n){n.Z=`import {
  Config,
  email,
  min,
  password,
  required,
  useForm,
} from '@by-l/react-form';
import { Button, Checkbox, Input } from 'antd';
import './index.css';
import { msg } from './utils';
import { FormItem } from './compoment/FormItem';

const config: Config = {
  email: {
    label: '\u90AE\u7BB1',
    formItem: <Input placeholder="e-mail" />,
    rules: [required(), email()],
  },
  parssword: {
    label: '\u5BC6\u7801',
    formItem: <Input placeholder="password" type="password" />,
    rules: [required(), min(6), password()],
  },
  remember: {
    formItem: <Checkbox>remember</Checkbox>,
    valueName: 'checked',
  },
};

const initialValue = {
  email: '666@qq.com',
  remember: true,
};

export default () => {
  const { items, submit } = useForm({
    initialValue,
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      error={item.error}
      formItem={item.formItem}
    />
  ));

  return (
    <div>
      {formItems}
      <Button className="m-l" onClick={submit}>
        \u767B\u5F55
      </Button>
    </div>
  );
};
`},76970:function(i,n){n.Z=`import {
  Config,
  email,
  min,
  password,
  required,
  useForm,
} from '@by-l/react-form';
import { Button, Input } from 'antd';
import { FormItem } from './compoment/FormItem';
import { msg } from './utils';

function reparssword(v: string, form: any) {
  if (form['parssword'] !== form['reparssword']) {
    throw '\u5BC6\u7801\u4E0D\u4E00\u81F4';
  }
}

const config: Config = {
  email: {
    label: '\u90AE\u7BB1',
    formItem: <Input placeholder="e-mail" />,
    rules: [required(), email()],
  },
  parssword: {
    label: '\u5BC6\u7801',
    formItem: <Input placeholder="password" type="password" />,
    rules: [required(), min(6), password()],
  },
  reparssword: {
    label: '\u91CD\u590D\u5BC6\u7801',
    formItem: <Input placeholder="password" type="password" />,
    rules: [reparssword],
  },
};

export default () => {
  const { items, submit } = useForm({
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      error={item.error}
      formItem={item.formItem}
    />
  ));

  return (
    <div>
      {formItems}
      <Button className="m-l" onClick={submit}>
        \u6CE8\u518C
      </Button>
    </div>
  );
};
`},63823:function(i,n){n.Z=`import { Config, required, useForm } from '@by-l/react-form';
import { Button, Input, Select } from 'antd';
import { FormItem } from './compoment/FormItem';
import { msg } from './utils';

const config: Config = {
  nickName: {
    label: '\u6635\u79F0',
    formItem: <Input placeholder="nick name" />,
    rules: [required()],
  },
  gender: {
    label: '\u6027\u522B',
    formItem: <Gender />,
    rules: [required()],
  },
  other: {
    label: '\u5176\u4ED6',
    formItem: <Input placeholder="other" />,
    show: (form: any) => form['gender'] === 'other',
    rules: [required()],
  },
};

const initialValue = {
  nickName: 'Musk',
  gender: 'male',
};

export default () => {
  const form = useForm({
    initialValue,
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
    onChange,
  });

  function fill() {
    form.setFormData({
      nickName: 'Elon Musk',
      gender: 'other',
      other: 'AI',
    });
    form.setError({});
  }
  /**
   * \u5982\u679Cgender\u53D1\u751F\u53D8\u5316\u5C31\u4FEE\u6539nickName
   */
  function onChange(formData: any, name: string) {
    if (name !== 'gender') return;
    const v = formData[name];
    if (v === 'female') form.setFormData({ nickName: 'lily\u{1F469}\u{1F3FB}' });
    if (v === 'male') form.setFormData({ nickName: 'tom\u{1F468}\u{1F3FB}' });
    if (v === 'other') form.setFormData({ nickName: 'siri\u{1F605}' });
  }

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      error={item.error}
      formItem={item.formItem}
    />
  ));

  return (
    <div>
      {formItems}
      <div className="m-l">
        <Button type="primary" onClick={form.submit}>
          submit
        </Button>
        <Button onClick={form.reset}>reset</Button>
        <Button type="link" onClick={fill}>
          fill
        </Button>
      </div>
    </div>
  );
};

function Gender(props: any) {
  return (
    <Select
      {...props}
      style={{ width: 180 }}
      placeholder="Select a option and change input text above"
      allowClear
    >
      <Select.Option value="male">male</Select.Option>
      <Select.Option value="female">female</Select.Option>
      <Select.Option value="other">other</Select.Option>
    </Select>
  );
}
`},8618:function(i,n){n.Z=`import { Config, required, useForm } from '@by-l/react-form';
import { Button, Input } from 'antd';
import { FormItem } from './compoment/FormItem';
import { FullName } from './compoment/FullName';
import { msg } from './utils';

const config: Config = {
  title: {
    label: '\u6807\u9898',
    formItem: <Input placeholder="title" />,
    rules: [required('title\u4E0D\u80FD\u4E3A\u7A7A')],
  },
  fullName: {
    label: '\u59D3\u540D',
    subForm: <FullName />,
  },
  other: {
    label: 'other',
    formItem: <Input placeholder="other" />,
  },
};

export default () => {
  const { items, submit } = useForm({
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      error={item.error}
      formItem={item.formItem}
    />
  ));

  return (
    <div>
      {formItems}
      <Button className="m-l" type="primary" onClick={submit}>
        submit
      </Button>
    </div>
  );
};
`},51899:function(i,n){n.Z=`import { ListConfig, useFormList } from '@by-l/react-form';
import { Button, Flex, Input } from 'antd';
import { ListItem } from './compoment/ListItem';
import { msg } from './utils';

const config: ListConfig = {
  formItem: <Input placeholder="placeholder..." />,
};

export default () => {
  const { items, submit, push, unshift, remove, error } = useFormList({
    config,
    onSuccess: (res: any) => msg(res),
    onFail: (err: string) => msg(err),
  });

  const formItems = items.map((item, i) => (
    <ListItem key={item.name} {...item} onDelete={() => remove(i)} />
  ));

  return (
    <Flex vertical gap={32} style={{ width: 300 }}>
      {formItems}
      <Button onClick={submit} type="primary">
        submit
      </Button>
      <Button onClick={() => push()}>add</Button>
      <Button onClick={() => unshift()}>add at head</Button>
      <div className="err">{error}</div>
    </Flex>
  );
};
`},89552:function(i,n){n.Z=`import { ListConfig, min, required, useFormList } from '@by-l/react-form';
import { Button, Flex, Input } from 'antd';
import { ListItem } from './compoment/ListItem';
import { msg } from './utils';

const config: ListConfig = {
  formItem: <Input placeholder="placeholder..." />,
  rules: [required()],
  listRules: [min(2, '\u4E0D\u80FD\u5C11\u4E8E2\u9879')],
};

let num = 1;

export default () => {
  const { items, submit, push, unshift, remove, error } = useFormList({
    config,
    onSuccess: (res: any) => msg(res),
    onFail: (err: string) => msg(err),
  });

  const formItems = items.map((item, i) => (
    <ListItem key={item.name} {...item} onDelete={() => remove(i)} />
  ));

  return (
    <Flex vertical gap={32} style={{ width: 300 }}>
      {formItems}
      <Button onClick={submit} type="primary">
        submit
      </Button>
      <Button onClick={() => push(num++)}>add</Button>
      <Button onClick={() => unshift(num++)}>add at head</Button>
      <div className="err">{error}</div>
    </Flex>
  );
};
`},9323:function(i,n){n.Z=`import { Button, Input } from 'antd';
import { min, required } from '../rules';
import { Config } from '../types';
import { useForm } from '../useForm';
import { FormItem } from './compoment/FormItem';
import { FullName } from './compoment/FullName';
import { NameListSimple } from './compoment/nameListSimple';
import { msg } from './utils';

const config: Config = {
  className: {
    label: '\u73ED\u7EA7',
    formItem: <Input placeholder="class" />,
    rules: [required()],
  },
  teacher: {
    label: '\u8001\u5E08',
    subForm: <FullName />,
  },
  students: {
    label: '\u5B66\u751F',
    formList: <NameListSimple />,
    rules: [required('\u6700\u5C11\u4E00\u4E2A\u5B66\u751F'), min(1, '\u6700\u5C11\u4E00\u4E2A\u5B66\u751F')],
  },
};

export default () => {
  const form = useForm({
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <div>
      {formItems}
      <Button className="m-l" type="primary" onClick={form.submit}>
        submit
      </Button>
    </div>
  );
};
`},3071:function(i,n){n.Z=`import { ListConfig, min, required, useFormList } from '@by-l/react-form';
import { Button, Flex } from 'antd';
import { FullName } from './compoment/FullName';
import { ListItem } from './compoment/ListItem';
import { msg } from './utils';

const config: ListConfig = {
  subForm: <FullName />,
  listRules: [required('\u6700\u5C113\u4E2A'), min(3, '\u6700\u5C113\u4E2A')],
};

export default () => {
  const { items, submit, push, remove, error } = useFormList({
    config,
    onSuccess: (res: any) => msg(res),
    onFail: (err: string) => msg(err),
  });

  const formItems = items.map((item, i) => (
    <ListItem
      key={item.name}
      formItem={item.formItem}
      error={item.error}
      onDelete={() => remove(i)}
    />
  ));

  return (
    <Flex vertical gap={32} style={{ width: 300 }}>
      {formItems}
      <Button onClick={submit} type="primary">
        submit
      </Button>
      <Button onClick={() => push()}>add</Button>
      <div className="err">{error}</div>
    </Flex>
  );
};
`},66907:function(i,n){n.Z=`import { Button, Input } from 'antd';
import { min, required } from '../rules';
import { Config } from '../types';
import { useForm } from '../useForm';
import { FormItem } from './compoment/FormItem';
import { FullName } from './compoment/FullName';
import { NameList } from './compoment/nameList';
import { msg } from './utils';

const config: Config = {
  className: {
    label: '\u73ED\u7EA7',
    formItem: <Input placeholder="class" />,
    rules: [required()],
  },
  teacher: {
    label: '\u8001\u5E08',
    subForm: <FullName />,
  },
  students: {
    label: '\u5B66\u751F',
    formList: <NameList />,
    rules: [required('\u6700\u5C113\u4E2A\u5B66\u751F'), min(3, '\u6700\u5C113\u4E2A\u5B66\u751F')],
  },
};

export default () => {
  const form = useForm({
    config,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <div>
      {formItems}
      <Button className="m-l" type="primary" onClick={form.submit}>
        submit
      </Button>
    </div>
  );
};
`},41825:function(i,n){n.Z=`import { ListConfig, useFormList } from '@by-l/react-form';
import { Button, Flex, Typography } from 'antd';
import { MyCard } from './compoment/Card';
import { ClassForm } from './compoment/ClassForm';
import { msg } from './utils';

const config: ListConfig = {
  subForm: <ClassForm />,
};

export default () => {
  const { items, submit, push, remove, getFormData } = useFormList({
    config,
    onSuccess: (res: any) => msg(res),
    onFail: (err: string) => msg(err),
  });

  const formItems = items.map((item, i) => (
    <MyCard
      key={item.name}
      formItem={item.formItem}
      onDelete={() => remove(i)}
    />
  ));

  return (
    <Flex vertical gap={32} style={{ width: 600 }}>
      {formItems}
      <Button onClick={submit} type="primary">
        submit
      </Button>
      <Button onClick={() => push()}>\u6DFB\u52A0\u73ED\u7EA7</Button>

      <Typography>
        <pre>
          {JSON.stringify(
            getFormData(),
            (k, v) => (v === undefined ? 'undefined' : v),
            2,
          )}
        </pre>
      </Typography>
    </Flex>
  );
};
`},47428:function(i,n){n.Z=`import React, { FC } from "react"
import { Button, Card } from 'antd'


interface MyCardProps {
  formItem?: any,
  onDelete: any
}

export const MyCard: FC<MyCardProps> = ({ formItem, onDelete }) => {
  return (
    <Card
      extra={<Button type='link' onClick={onDelete} >\u79FB\u9664</Button>}>
      {formItem}
    </Card>
  )
}`},16930:function(i,n){n.Z=`import { Config, formItem, formList, label, min, required, rules, subForm, useForm } from "@by-l/react-form";
import { Input } from "antd";
import { FullName } from "./FullName";
import { NameList } from "./nameList";
import { FormItem } from "./FormItem";
import { FC, useEffect } from "react";

type N = {
  firstName: string,
  lastName: string
}

class ConfigImpl {
  @formItem(<Input placeholder="class" />)
  @label('\u73ED\u7EA7')
  @rules(required())
  className: string

  @subForm(<FullName />)
  @label('\u8001\u5E08')
  teacher: N

  @formList(<NameList />)
  @label('\u5B66\u751F')
  @rules(required('\u6700\u5C111\u4E2A\u5B66\u751F'), min(1, '\u6700\u5C111\u4E2A\u5B66\u751F'))
  students: N[]
}

interface FullNameProps {
  value?: any,
  onChange?: Function,
  father?: any
}

export const ClassForm: FC<FullNameProps> = (props) => {
  const form = useForm({
    config: ConfigImpl,
    onChange: props.onChange,
    father: props.father
  })

  useEffect(() => {
    form.setFormData(props.value)
  }, [props.value])

  const formItems = form.items.map(item => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ))

  return (
    <div>
      {formItems}
    </div>
  )
}`},44616:function(i,n){n.Z=`import { FC } from "react"
import '../index.css'

interface FormItemProps {
  label?: string,
  formItem?: any,
  error?: any,
}

export const FormItem: FC<FormItemProps> = ({ label, formItem, error }) => {

  return (
    <div className='container' data-err={error} >
      <div className='label' >{label}</div>
      <div>{formItem}</div>
    </div>
  )
}`},21436:function(i,n){n.Z=`import { Flex, Input } from "antd"
import { FC, useEffect } from "react"
import { formItem, required, rules, useForm } from "@by-l/react-form"
import '../index.css'

class ConfigImpl {
  @formItem(<Input placeholder='first name' />)
  @rules(required('firstName\u4E0D\u80FD\u4E3A\u7A7A'))
  firstName: string

  @formItem(<Input placeholder='last name' />)
  @rules(required('lastName\u4E0D\u80FD\u4E3A\u7A7A'))
  lastName: string
}

interface FullNameProps {
  value?: any,
  onChange?: Function,
  father?: any
}

export const FullName: FC<FullNameProps> = (props) => {

  const form = useForm({
    config: ConfigImpl,
    onChange: props.onChange,
    father: props.father
  })

  useEffect(() => {
    form.setFormData(props.value)
  }, [props.value])

  const formItems = form.items.map(item => (
    <div className='name' data-err={item.error} key={item.name} >
      {item.formItem}
    </div>
  ))

  return <Flex gap={9}>
    {formItems}
  </Flex>
}
`},91761:function(i,n){n.Z=`import { Button, Flex } from "antd"
import { FC } from "react"

interface ListItemProps {
  formItem?: any,
  error?: any,
  onDelete: any
}

export const ListItem: FC<ListItemProps> = ({ formItem, error, onDelete }) => {
  return (
    <Flex className='item' data-err={error} align='center' gap={3} >
      {formItem}
      <Button onClick={onDelete} size='small' style={{ color: '#999' }} type='text' >\u5220\u9664</Button>
    </Flex>
  )
}`},8790:function(i,n){n.Z=`import { ListConfig, useFormList } from '@by-l/react-form';
import { Button, Flex } from 'antd'
import { FullName } from './FullName';
import { ListItem } from './ListItem';
import { FC, useEffect } from 'react';

export const nameListConfig: ListConfig = {
  subForm: <FullName />,
};

interface NameListProps {
  value?: any,
  onChange?: Function,
  father?: any
}

export const NameList: FC<NameListProps> = (props) => {

  const form = useFormList({
    father: props.father,
    config: nameListConfig,
    onChange: props.onChange
  })

  useEffect(() => {
    form.setFormList(props.value)
  }, [props.value])

  const formItems = form.items.map((item, i) => (
    <ListItem
      key={item.name}
      formItem={item.formItem}
      error={item.error}
      onDelete={() => form.remove(i)}
    />
  ))

  return (
    <Flex vertical gap={32} style={{ width: 300 }}>
      {formItems}
      <Button onClick={() => form.push()} >\u6DFB\u52A0</Button>
    </Flex>
  )
}
`},26242:function(i,n){n.Z=`import { ListConfig, required, useFormList } from '@by-l/react-form';
import { Button, Flex, Input } from 'antd'
import { ListItem } from './ListItem';
import { FC, useEffect } from 'react';

export const nameListConfig: ListConfig = {
  formItem: <Input placeholder='name...' />,
  rules: [required()],
};

interface NameListProps {
  value?: any,
  onChange?: Function,
  father?: any
}

export const NameListSimple: FC<NameListProps> = (props) => {

  const form = useFormList({
    father: props.father,
    config: nameListConfig,
    onChange: props.onChange
  })

  useEffect(() => {
    form.setFormList(props.value)
  }, [props.value])

  const formItems = form.items.map((item, i) => (
    <ListItem
      key={item.name}
      formItem={item.formItem}
      error={item.error}
      onDelete={() => form.remove(i)}
    />
  ))

  return (
    <Flex vertical gap={32} style={{ width: 300 }}>
      {formItems}
      <Button onClick={() => form.push()} >\u6DFB\u52A0</Button>
    </Flex>
  )
}
`},49956:function(i,n){n.Z=`import {
  email,
  formItem,
  label,
  min,
  password,
  required,
  rules,
  useForm,
  valueName,
} from '@by-l/react-form';
import { Button, Checkbox, Input } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { msg } from '../utils';

class ConfigImpl {
  @label('\u90AE\u7BB1')
  @formItem(<Input />)
  @rules(required(), email())
  email: string;

  @label('\u5BC6\u7801')
  @formItem(<Input type="password" />)
  @rules(required(), min(6), password())
  password: string;

  @formItem(<Checkbox>\u8BB0\u4F4F</Checkbox>)
  @valueName('checked')
  remember: boolean;
}

const initialValue = {
  email: '666@qq.com',
  remember: true,
};

export default () => {
  const form = useForm({
    config: ConfigImpl,
    initialValue,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      formItem={item.formItem}
      label={item.label}
      error={item.error}
    />
  ));

  return (
    <>
      {formItems}
      <Button className="m-l" onClick={form.submit}>
        \u767B\u5F55
      </Button>
    </>
  );
};
`},3415:function(i,n){n.Z=`import { email, min, password, required } from '@by-l/react-form/rules';
import { useForm } from '@by-l/react-form/useForm';
import { formItem, label, rules } from '@by-l/react-form/useForm/decorator';
import { Button, Input } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { msg } from '../utils';

class ConfigImpl {
  @formItem(<Input placeholder="e-mail" />)
  @label('\u90AE\u7BB1')
  @rules(required(), email())
  email: string;

  @formItem(<Input placeholder="password" type="password" />)
  @label('\u5BC6\u7801')
  @rules(required(), password(), min(6))
  parssword: string;

  @formItem(<Input placeholder="password" type="password" />)
  @label('\u91CD\u590D\u5BC6\u7801')
  @rules(reparssword)
  reparssword: string;
}

function reparssword(reparssword: string, form: any) {
  if (form['parssword'] !== reparssword) {
    throw '\u5BC6\u7801\u4E0D\u4E00\u81F4';
  }
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <>
      {formItems}
      <Button className="m-l" onClick={form.submit}>
        \u6CE8\u518C
      </Button>
    </>
  );
};
`},51574:function(i,n){n.Z=`import { required } from '@by-l/react-form/rules';
import { useForm } from '@by-l/react-form/useForm';
import {
  formItem,
  label,
  rules,
  show,
} from '@by-l/react-form/useForm/decorator';
import { Button, Input, Select } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { msg } from '../utils';

class ConfigImpl {
  @formItem(<Input placeholder="nick name" />)
  @label('\u6635\u79F0')
  @rules(required())
  nickName: string;

  @formItem(<Gender />)
  @label('\u6027\u522B')
  @rules(required())
  gender: 'male' | 'female' | 'other';

  @formItem(<Input placeholder="other" />)
  @label('\u5176\u4ED6')
  @rules(required())
  @show((data: ConfigImpl) => data.gender === 'other')
  other: string;
}

const initialValue = {
  nickName: 'Musk',
  gender: 'male',
};

export default () => {
  const form = useForm<ConfigImpl>({
    config: ConfigImpl,
    initialValue,
    onChange,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  function onChange(
    formData: ConfigImpl,
    name: keyof typeof ConfigImpl.prototype,
  ) {
    if (name !== 'gender') return;
    if (formData.gender === 'male')
      form.setFormData({ nickName: 'tom\u{1F468}\u{1F3FB}' }).clearError('nickName');
    if (formData.gender === 'female')
      form.setFormData({ nickName: 'lily\u{1F469}\u{1F3FB}' }).clearError('nickName');
    if (formData.gender === 'other')
      form.setFormData({ nickName: 'siri\u{1F605}' }).clearError('nickName');
  }

  function fill() {
    form
      .setFormData({
        nickName: 'Elon Musk',
        gender: 'other',
        other: 'AI',
      })
      .clearError();
  }

  return (
    <>
      {formItems}
      <div className="m-l">
        <Button type="primary" onClick={form.submit}>
          submit
        </Button>
        <Button onClick={form.reset}>reset</Button>
        <Button type="link" onClick={fill}>
          fill
        </Button>
      </div>
    </>
  );
};

function Gender(props: any) {
  return (
    <Select
      {...props}
      style={{ width: 180 }}
      placeholder="Select a option and change input text above"
      allowClear
    >
      <Select.Option value="male">male</Select.Option>
      <Select.Option value="female">female</Select.Option>
      <Select.Option value="other">other</Select.Option>
    </Select>
  );
}
`},99383:function(i,n){n.Z=`import {
  formItem,
  label,
  required,
  rules,
  subForm,
  useForm,
} from '@by-l/react-form';
import { Button, Input } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { FullName } from '../compoment/FullName';
import { msg } from '../utils';

class ConfigImpl {
  @formItem(<Input placeholder="title" />)
  @label('\u6807\u9898')
  @rules(required('title\u4E0D\u80FD\u4E3A\u7A7A'))
  title: string;

  @subForm(<FullName />)
  @label('\u59D3\u540D')
  fullName: string;

  @formItem(<Input placeholder="other" />)
  @label('other')
  other: string;
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <>
      {formItems}
      <Button className="m-l" type="primary" onClick={form.submit}>
        submit
      </Button>
    </>
  );
};
`},46222:function(i,n){n.Z=`import {
  formItem,
  formList,
  label,
  min,
  required,
  rules,
  subForm,
  useForm,
} from '@by-l/react-form';
import { Button, Input } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { FullName } from '../compoment/FullName';
import { NameListSimple } from '../compoment/nameListSimple';
import { msg } from '../utils';

class ConfigImpl {
  @formItem(<Input placeholder="class" />)
  @label('\u73ED\u7EA7')
  @rules(required())
  className: string;

  @subForm(<FullName />)
  @label('\u8001\u5E08')
  teacher: object;

  @formList(<NameListSimple />)
  @label('\u5B66\u751F')
  @rules(required('\u6700\u5C11\u4E00\u4E2A\u5B66\u751F'), min(1, '\u6700\u5C11\u4E00\u4E2A\u5B66\u751F'))
  students: string[];
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <>
      {formItems}
      <Button className="m-l" type="primary" onClick={form.submit}>
        submit
      </Button>
    </>
  );
};
`},25147:function(i,n){n.Z=`import {
  formItem,
  formList,
  label,
  min,
  required,
  rules,
  subForm,
  useForm,
} from '@by-l/react-form';
import { Button, Input } from 'antd';
import { FormItem } from '../compoment/FormItem';
import { FullName } from '../compoment/FullName';
import { NameList } from '../compoment/nameList';
import { msg } from '../utils';

class ConfigImpl {
  @formItem(<Input placeholder="class" />)
  @label('\u73ED\u7EA7')
  @rules(required())
  className: string;

  @subForm(<FullName />)
  @label('\u8001\u5E08')
  teacher: object;

  @formList(<NameList />)
  @label('\u5B66\u751F')
  @rules(required('\u6700\u5C113\u4E2A\u5B66\u751F'), min(3, '\u6700\u5C113\u4E2A\u5B66\u751F'))
  students: string[];
}

export default () => {
  const form = useForm({
    config: ConfigImpl,
    onSuccess: (data) => msg(data),
    onFail: (err) => msg(err),
  });

  const formItems = form.items.map((item) => (
    <FormItem
      key={item.name}
      label={item.label}
      formItem={item.formItem}
      error={item.error}
    />
  ));

  return (
    <>
      {formItems}
      <Button className="m-l" type="primary" onClick={form.submit}>
        submit
      </Button>
    </>
  );
};
`},82415:function(i,n){n.Z=`.container {
  display: flex;
  margin-bottom: 30px;
  width: 500px;
}

.label {
  width: 100px;
  text-align: right;
  margin-right: 20px;
  padding-top: 5px;
}

[data-err] {
  position: relative;
}

[data-err]::after {
  position: absolute;
  content: attr(data-err);
  color: deeppink;
  top: 110%;
  left: 120px;
  font-size: 12px;
}

.name,
.item {
  position: relative;
}

.name::after,
.item::after {
  position: absolute;
  content: attr(data-err);
  color: deeppink;
  top: 110%;
  left: 0px;
  font-size: 12px;
}

.m-l {
  margin-left: 120px;
}

Button {
  margin-right: 9px;
}

.err {
  color: deeppink;
  font-size: 12px;
}`},82150:function(i,n){n.Z=`
export function msg(v: any) {

  alert(
    JSON.stringify(
      v,
      (k, v) => v === undefined ? 'undefined' : v,
      2
    )
  )
}`},17431:function(i,n){n.Z=`import { useRef, useState } from "react"

export const useStatePro = <T>(value: T) => {
  const [v, setV] = useState<T>(value)
  const vRef = useRef<T>(value)

  const getValue = () => {
    return vRef.current
  }

  // \u56E0\u4E3AgetValue\u80FD\u83B7\u53D6\u5230\u6700\u65B0\u503C,\u6240\u4EE5\u4E0D\u9700\u8981\u4F20\u56DE\u8C03\u51FD\u6570\u4E86
  const setValue = (value: any) => {
    if (isFunction(value)) {
      setV(v => {
        const newValue = value(v)
        vRef.current = newValue
        return newValue
      })
    } else {
      setV(value)
      vRef.current = value
    }
  }

  return [v, setValue, getValue] as const
}

function isFunction(v: any) {
  if (typeof v === 'function') {
    return true
  }
  return false;
}
`},40909:function(i,n){n.Z=`export const required = (msg?: string) => (v: any, formData: any) => {
  if (!v) {
    throw msg || \`\u4E0D\u80FD\u4E3A\u7A7A\`
  }
}

export const max = (n: number, msg?: string) => (v: any) => {
  if (!v) return
  if (v.length > n) {
    throw msg || \`\u957F\u5EA6\u4E0D\u80FD\u5927\u4E8E\${n}\`
  }
}

export const min = (n: number, msg?: string) => (v: any) => {
  if (!v) return
  if (v.length < n) {
    throw msg || \`\u957F\u5EA6\u4E0D\u80FD\u5C0F\u4E8E\${n}\`
  }
}

export const nickName = (msg?: string) => (v: string) => {
  if (!v) return
  const errInfo = msg || '\u8BF7\u586B\u5199\u4E2D\u6587\u6216\u5B57\u6BCD\u6216\u6570\u5B57\u6216\u4E0B\u5212\u7EBF'
  const res = /^[a-zA-Z0-9_\\u4e00-\\u9fa5]+$/.test(v)
  if (res === false) throw errInfo
}

export const password = () => (v: string) => {
  if (!v) return
  const res1 = /^(?=.*\\d).{1,}$/.test(v)
  if (res1 === false) throw '\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u6570\u5B57'
  const res2 = /^(?=.*[a-zA-Z]).{1,}$/.test(v)
  if (res2 === false) throw '\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u5B57\u6BCD'
  const res3 = /^(?=.*[@$!%*?&]).{1,}$/.test(v)
  if (res3 === false) throw '\u81F3\u5C11\u5305\u542B\u4E00\u4E2A\u7279\u6B8A\u7B26\u53F7@$!%*?&'
}

export const email = (msg?: string) => (v: string) => {
  if (!v) return
  const errInfo = msg || '\u8BF7\u8F93\u5165\u6B63\u786Eemail\u5730\u5740'
  const res = /^[A-Za-z0-9\\u4e00-\\u9fa5]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$/.test(v)
  if (res === false) throw errInfo
}

export const phone = (msg?: string) => (v: string) => {
  if (!v) return
  const errInfo = msg || '\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u624B\u673A\u53F7\u7801'
  const res = /^1[3456789]\\d{9}$/.test(v)
  if (res === false) throw errInfo
}

export const idCard = (msg?: string) => (v: string) => {
  if (!v) return
  const errInfo = msg || '\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u8EAB\u4EFD\u8BC1\u53F7\u7801'
  const res = /(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)/.test(v)
  if (res === false) throw errInfo
}

// export const subForm = (config: Config) => async (formData: any) => {
//   let errors: any = {}
//   let hasError = false
//   if (!formData) formData = initFormData(config)


//   for (let name in formData) {
//     const value = formData[name]
//     const { rules } = config[name]

//     try {
//       await ruleCheck(value, rules, formData)
//     } catch (error) {
//       hasError = true
//       errors[name] = error
//     }
//   }

//   if (hasError) {
//     throw errors
//   }
// };

// export const formList = (config: FormListConfig) => async (formData: any[]) => {
//   let errorList: any = []
//   let hasError = false
//   if (!formData) formData = [undefined]

//   for (let i = 0; i < formData.length; i++) {
//     const value = formData[i]
//     const { rules } = config

//     try {
//       await ruleCheck(value, rules)
//     } catch (error) {
//       errorList[i] = error
//       hasError = true
//     }
//   }

//   if (hasError) {
//     throw errorList
//   }
// }

// async function ruleCheck(value: any, rules?: Function[], formData?: any) {
//   if (!rules) return

//   for (let i = 0; i < rules.length; i++) {
//     const checkFn = rules[i]
//     await checkFn(value, formData)
//   }
// }


`},43486:function(i,n){n.Z=`import { Config, ConfigItem, Obj, UseFormProps } from "./types"


// export function getFirstError(err: Obj): string {
//   if (!err) return ''
//   const key = Object.keys(err)[0]
//   if (typeof err[key] === 'string') {
//     return err[key]
//   }
//   return getFirstError(err[key])
// }

// export const getV = (o: any) => (...args: any[]) => {
//   args.forEach(key => {
//     if (o) {
//       o = o[key]
//     }
//   })

//   return o
// }

/**
 * \u5BF9\u8C61\u8F6C\u6570\u7EC4
 */
// export function obj2Array(obj: any) {
//   if (!obj) return
//   const arr = []
//   for (let key in obj) {
//     arr.push(obj[key])
//   }

//   return arr
// }

export function getItem(configItem: ConfigItem) {
  const { subForm, formList, formItem } = configItem
  if (subForm) return subForm
  if (formList) return formList
  return formItem
}

// function getInitValue(name: string, config: Config, initialValue: Obj) {
//   if (initialValue) {
//     return initialValue[name]
//   }

//   if (config[name].initValue) {
//     return config[name].initValue
//   }
// }


/**
 *
 * 
 * 
 * 
 *  
 */
export function initData(props: UseFormProps) {
  const { config, initialValue } = props
  const res: any = {}

  for (let name in initialValue) {
    config[name].initValue = initialValue[name]
  }

  for (let name in config) {
    res[name] = config[name].initValue
  }

  return res
}

export function getValue(e: any, valueName = 'value') {
  if (!e) return e
  if (!e.target) return e
  return e.target[valueName]
}

let i = 0
export function createName() {
  const time = new Date().getTime()
  return \`\${time}-\${i++}\`
}

export function isFunction(value: any) {
  return typeof value === 'function';
}

export function isArray(value: any) {
  return Array.isArray(value);
}`},70899:function(i,n){n.Z=`import { UseFormProps, FormData, Err, Config } from "../types";
import { initData } from "../tools";
import { useCheck } from "./useCheck";
import { useBind } from "./useBind";
import { useFormData } from "./useFormData";
import { useStatePro } from "../hooks/useStatePro";


export const useForm = <T>(props: UseFormProps) => {
  props.config = configInit(props.config)

  type N = keyof T // \u8868\u5355\u5C5E\u6027: 'username' | 'password' | 'age'
  type F = FormData<T>
  type E = Err<T>

  const [data, setData, getData] = useFormData<F>(props)
  const [error, setError, getErrs] = useStatePro<E>({})

  const checker = useCheck(
    props,
    [data, setData, getData],
    [error, setError, getErrs],
  )

  const items = useBind(
    props,
    [data, setData, getData],
    [error, setError, getErrs],
    checker,
  )

  const clearError = (name?: N) => {
    if (!name) {
      setError({})
      return
    }
    setError((err: E) => {
      err[name] = undefined
      return err
    })

    return { clearError }
  }

  const setFormData = (formData: F) => {
    setData({
      ...data,
      ...formData
    })

    return { clearError }
  }


  const reset = () => {
    setData(initData(props))
    setError({})
  }

  async function submit() {
    const res = await checker.submit()
    if (res.hasError) {
      props.onFail && props.onFail(res.firstError)
    } else {
      props.onSuccess && props.onSuccess(data)
    }
  }

  return {
    submit,
    checkForm: checker.checkForm,
    setFormData,
    setError,
    reset,
    getFormData: data,
    items
  }
}


function configInit(config: any): Config {
  if (typeof config === 'function') {

    config.create = function () {
      if (!config.that) {
        config.that = new config()
      }
      return config.that
    }

    return config.create().config
  }

  return config
}`},37684:function(i,n){n.Z=`import { Config } from '@by-l/react-form';
import { cloneElement, useMemo } from "react"
import { Obj, UseFormProps } from "../types"
import { useCheck } from "./useCheck"
import { getItem, getValue } from "../tools"


export const useBind = (
  useFormProps: UseFormProps,
  [formData, setFormData, getFormData]: [any, Function, Function],
  [error, setErrs, getErrs]: [any, Function, Function],
  checker: ReturnType<typeof useCheck>,
) => {

  const { config, father } = useFormProps

  const change = (name: string) => async (e: any) => {
    const fData = getFormData()
    fData[name] = getValue(e, config[name].valueName)
    setFormData(fData)

    if (useFormProps.onChange) {
      useFormProps.onChange(fData, name)
    }

    const err = await checker.checkItem(name, fData)
    const errs = getErrs()
    errs[name] = err
    setErrs({ ...errs })
  }

  const cloneItem = (name: string) => {
    const { valueName = 'value' } = config[name]

    const props: Obj = {
      [valueName]: formData[name],
      onChange: change(name),
      name,
      key: name
    }
    // \u5982\u679C\u662F<input/>, \u5C31\u4E0D\u4F20\u5165subscrible
    if (!config[name].formItem) {
      props.father = father || checker.subscrible
    }

    const item = getItem(config[name])
    return cloneElement(item, props)
  }


  return useMemo(() => {
    const arr = []

    for (let name in formData) {
      arr.push({
        name,
        formItem: cloneItem(name),
        label: config[name].label,
        error: error[name]
      })
    }

    return arr
  }, [formData, error])
}
`},50721:function(i,n){n.Z=`import { FormData } from './../types';
import { useEffect, useRef } from "react"
import { CheckFn, Obj, UseFormProps } from "../types"
import { isFunction } from "../tools"


export const useCheck = (
  useFormProps: UseFormProps,
  [data, setData, getData]: [Obj, Function, Function],
  [error, setError, getError]: [Obj, Function, Function]
) => {
  const { config, father } = useFormProps

  const checkForm = async () => {
    let error: Obj = {}
    let hasError = false
    let firstError
    const formData = getData()

    for (let name in formData) {
      error[name] = await checkItem(name, formData)
      if (error[name]) {
        hasError = true
        if (!firstError) firstError = error[name]
      }
    }

    setError(error)

    return {
      hasError,
      error,
      firstError
    }
  }

  const listRef = useRef<CheckFn[]>([checkForm])
  /**
   * \u6839\u8868\u5355\u8BA2\u9605\u5B50\u8868\u5355\u7684checkForm
   */
  useEffect(() => {
    const sub = father
    if (isFunction(sub) === false) {
      return
    }
    const unSub = sub(checkForm)
    return () => unSub()
  }, [])

  const checkItem = async (name: string, formData: any) => {
    const rules = config[name].rules || []
    const err = await check(name, formData, rules)
    return err as string
  }

  async function submit() {
    let hasError = false
    let firstError
    let error

    for (let i = 0; i < listRef.current.length; i++) {
      const checkFn = listRef.current[i]
      const res = await checkFn()
      if (res.hasError) hasError = true
      if (res.hasError && !firstError) firstError = res.firstError
      if (i === 0) error = res.error
    }

    return {
      hasError,
      firstError,
      error
    }
  }


  function subscrible(checkFn: CheckFn) {
    listRef.current.push(checkFn)

    return () => {
      const index = listRef.current.indexOf(checkFn)
      listRef.current.splice(index, 1)
    }
  }

  return {
    submit,
    checkItem,
    checkForm,
    subscrible
  }
}

async function check(name: string, formData: Obj, rules: Function[]) {
  let err = undefined

  for (let rule of rules) {
    try {
      await rule(formData[name], formData)
    } catch (error) {
      err = error
      break
    }
  }

  return err
}
`},44725:function(i,n){n.Z=`import { useEffect, useMemo, useRef, useState } from "react"
import { UseFormProps } from "../types"
import { initData } from "../tools"

export function useFormData<F>(props: UseFormProps) {
  const { config } = props
  const [data, setData] = useState(initData(props))
  const formDataRef = useRef(data)

  const formData = useMemo(() => {
    let filteredFormData: any = {}

    for (let name in config) {
      const show = config[name].show
      if (show && show(data) === false) {
        continue
      }
      filteredFormData[name] = data[name]
    }

    return filteredFormData as F
  }, [data])

  useEffect(() => {
    formDataRef.current = formData
  }, [formData])

  function getData() {
    return formDataRef.current
  }

  return [formData, setData, getData] as const
}`}}]);
